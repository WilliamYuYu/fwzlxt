package com.example.demo2.controller;

import com.example.demo2.domain.UserInfo;
import com.example.demo2.domain.UserInfoList;
import com.example.demo2.domain.dao.IUserInfoDao;
import com.example.demo2.domain.dao.UserInfoQueryPara;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/*import org.springframework.transaction.annotation.Transactional;*/
import pengesoft.core.PsCoreRuntimeException;
import pengesoft.service.ApplicationBase;
import pengesoft.utils.AssertUtils;
import pengesoft.utils.StringHelper;

import java.util.List;
import java.util.UUID;

/**
 * IUserMgeSvr 接口实现。用户管理服务.
 *
 * @auther: 向朗.
 * @date: 2019-11-26 13:13:15.
 * <p>
 * Copyright (C) 2008 - 鹏业软件公司
 */
@Service
/*@Transactional*/
public class UserMgeSvr extends ApplicationBase implements IUserMgeSvr {

    @Autowired
    private IUserInfoDao userInfoDao;

    /**
     * 构造方法
     */
    @Autowired
    public UserMgeSvr() {

    }

    void idCardIsExit(String idCard) {
        UserInfoQueryPara param = new UserInfoQueryPara();
        param.setParamByIdCard(idCard);
        if (getUserCount(param) > 0) {
            throw new PsCoreRuntimeException("证件号码[" + idCard + "]已存在.");
        }
    }

    /**
     * 添加用户信息  .
     *
     * @param idCard 证件号码.
     * @param name   用户名.
     * @param sex    性别.
     * @param phone  电话.
     */
    @Override
    public String addUserInfo(String idCard, String name, int sex, String phone) {
        AssertUtils.ThrowArgNullException(idCard, "idCard", true);
        AssertUtils.ThrowArgNullException(name, "name", true);
        idCardIsExit(idCard);
        UserInfo userInfo = new UserInfo();
        userInfo.setUserId(UUID.randomUUID().toString());
        userInfo.setIdCard(idCard);
        userInfo.setUserName(name);
        userInfo.setSex(sex);
        if (!StringHelper.isNullOrEmpty(phone)) {
            userInfo.setPhone(phone);
        }
        userInfoDao.insert(userInfo);
        return userInfo.getUserId();
    }

    /**
     * 获取用户信息  .
     *
     * @param idCard 证件号码.
     */
    @Override
    public UserInfo getUserDetail(String idCard) {
        AssertUtils.ThrowArgNullException(idCard, "idCard", true);
        UserInfoQueryPara param = new UserInfoQueryPara();
        param.setParamByIdCard(idCard);
        UserInfoList list = getUserList(param);

        return list.size() > 0 ? list.get(0) : null;
    }

    /**
     * 删除用户信息  .
     *
     * @param userId 用户Id.
     */
    @Override
    public void deleteUserInfo(String userId) {
        //TODO: 未实现.
    }

    /**
     * 查询用户列表  .
     *
     * @param param 查询参数.
     */
    @Override
    public UserInfoList getUserList(UserInfoQueryPara param) {
        if (param == null) {
            param = new UserInfoQueryPara();
        }
        List<UserInfo> list = userInfoDao.queryList(param, 0, -1);
        UserInfoList ret = new UserInfoList();
        ret.addFrom(list);
        return ret;
    }

    private int getUserCount(UserInfoQueryPara param) {
        if (param == null) {
            param = new UserInfoQueryPara();
        }
        return userInfoDao.queryCount(param);
    }
}


