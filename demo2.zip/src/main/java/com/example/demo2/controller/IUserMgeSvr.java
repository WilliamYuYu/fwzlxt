package com.example.demo2.controller;

import com.example.demo2.domain.UserInfo;
import com.example.demo2.domain.UserInfoList;
import com.example.demo2.domain.dao.UserInfoQueryPara;
import pengesoft.service.IApplication;
import pengesoft.service.PublishMethod;
import pengesoft.service.PublishName;
import pengesoft.utils.StringHelper;

/**
 * IUserMgeSvr 接口定义。用户管理服务.
 *
 * @auther: 向朗.
 * @date: 2019-11-26 13:17:26.
 * <p>
 * 文件由鹏业软件模型工具生成(模板名称：JavaAppService),一般不应直接修改此文件.
 * Copyright (C) 2008 - 鹏业软件公司
 */
@PublishName("UserMgeSvr")
public interface IUserMgeSvr extends IApplication {

    /**
     * 添加用户信息  .
     *
     * @param idCard 证件号码.
     * @param name   用户名.
     * @param sex    性别.
     * @param phone  电话.
     */
    @PublishMethod
    String addUserInfo(String idCard, String name, int sex, String phone);

    /**
     * 获取用户信息  .
     *
     * @param idCard 证件号码
     */
    @PublishMethod
    UserInfo getUserDetail(String idCard);

    /**
     * 删除用户信息  .
     *
     * @param userId 用户Id.
     */
    @PublishMethod
    void deleteUserInfo(String userId);

    /**
     * 查询用户列表  .
     *
     * @param param 查询参数.
     */
    @PublishMethod
    UserInfoList getUserList(UserInfoQueryPara param);

}

