package com.example.demo2.domain.dao;

import com.example.demo2.domain.UserInfo;
import org.springframework.stereotype.Repository;
import pengesoft.db.DataProvider;

/**
 * 用户信息 数据访问接口基本实现类.
 *
 * @auther: 向朗.
 * @date: 2019-11-26 13:09:24.
 * <p>
 * 文件由鹏业软件模型工具生成(模板名称：JavaDaoImp),一般不应直接修改此文件.
 * Copyright (C) 2008 - 鹏业软件公司
 */
@Repository
public class UserInfoDao extends DataProvider<UserInfo> implements IUserInfoDao {

    /*
        default statement ids:

        InsertStatementId: com.example.usermgt.dao.UserInfoDao.insertUserInfo.
        UpdateStatementId: com.example.usermgt.dao.UserInfoDao.updateUserInfo.
        DeleteStatementId: com.example.usermgt.dao.UserInfoDao.deleteUserInfo.
        GetHasDetailStatementId: com.example.usermgt.dao.UserInfoDao.getUserInfo.
        GetNoDetailStatementId: com.example.usermgt.dao.UserInfoDao.getBaseUserInfo.
        QueryCountStatementId: com.example.usermgt.dao.UserInfoDao.queryUserInfoCount.
        QueryHasDetailListStatementId: com.example.usermgt.dao.UserInfoDao.queryUserInfoList.
        QueryNoDetailListStatementId: com.example.usermgt.dao.UserInfoDao.queryBaseUserInfoList.

        If you need to change, you can rewrite the corresponding get method.
     */

}
