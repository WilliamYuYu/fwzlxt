package com.example.demo2.domain.dao;

import com.example.demo2.domain.UserInfo;
import pengesoft.db.QueryParameter;
import pengesoft.utils.StringHelper;

/**
 * 用户信息 查询参数类。
 *
 * @auther: 向朗.
 * @date: 2019-11-26 13:09:27.
 *
 * 文件由鹏业软件模型工具生成(模板名称：JavaQueryPara),一般不应直接修改此文件.
 * Copyright (C) 2008 - 鹏业软件公司
 */
public class UserInfoQueryPara extends QueryParameter {

    /**
     * 缺省序列化id
     */
    private static final long serialVersionUID = 1L;
    /**
     * 常数 查询属性名(用户Id).
     */
    public static final String QueryAttr_UserId = "userId";
    /**
     * 常数 查询属性名(用户名).
     */
    public static final String QueryAttr_UserName = "userName";
    /**
     * 常数 查询属性名(证件号码).
     */
    public static final String QueryAttr_IdCard = "idCard";
    /**
     * 常数 查询属性名(性别).
     */
    public static final String QueryAttr_Sex = "sex";
    /**
     * 常数 查询属性名(电话).
     */
    public static final String QueryAttr_Phone = "phone";

    /**
     * 常数 排序属性名(用户Id).
     */
    public static final String OrderAttr_UserId = "userId";
    /**
     * 常数 排序属性名(用户名).
     */
    public static final String OrderAttr_UserName = "userName";
    /**
     * 常数 排序属性名(证件号码).
     */
    public static final String OrderAttr_IdCard = "idCard";
    /**
     * 常数 排序属性名(性别).
     */
    public static final String OrderAttr_Sex = "sex";
    /**
     * 常数 排序属性名(电话).
     */
    public static final String OrderAttr_Phone = "phone";

    /**
     * 默认构造方法
     */
    public UserInfoQueryPara() {
        super();
    }

    /**
     * 构造函数,指定参数对象及排序字段
     *
     * @param data  查询参数对象
     * @param order 排序字段
     * @param isAse true升序，false降序
     */
    public UserInfoQueryPara(UserInfo data, String order, boolean isAse) {
        super();
        SetQueryPara(data, order, isAse);
    }

    /**
     * 构造函数,指定参数对象及排序字段
     *
     * @param data 查询参数对象
     */
    public UserInfoQueryPara(UserInfo data) {
        super();
        SetQueryPara(data, null, false);
    }

    /**
     * 指定查询参数对象及排序字段
     *
     * @param data  查询参数对象
     * @param order 排序字段
     * @param isAse true升序，false降序
     */
    public void SetQueryPara(UserInfo data, String order, boolean isAse) {
        if (data != null) {
            setParamByUserId(data.getUserId());
            setParamByUserName(data.getUserName());
            setParamByIdCard(data.getIdCard());
            setParamBySex(data.getSex());
            setParamByPhone(data.getPhone());
        }
        if (!StringHelper.isNullOrEmpty(order))
            addOrderBy(order, isAse);
    }

    /**
     * 增加用用户Id匹配条件(target like userId)，key:userId.
     * @param userId 用户Id匹配条件参数
     */
    public void setParamByUserId(String userId){
        addParameter(QueryAttr_UserId, userId);
    }

    /**
     * 增加用用户Id匹配条件(userId为empty时也会加入此条件)，不空时(target like userId)，key:userId，为空时(target is null or target = '')，key:userId.
     * @param userId 用户Id匹配条件参数
     */
    public void setParamByUserIdInEmpty(String userId){
        put(QueryAttr_UserId, userId);
    }

    /**
     * 增加用户Id枚举条件(target in (userIds))，key:userId_Enum.
     * @param userIds 用户Id数组条件参数
     */
    public void setParamByUserId_Enum(String... userIds){
        addParameterByEnum(QueryAttr_UserId, userIds);
    }

    /**
     * 增加用用户名匹配条件(target like userName)，key:userName.
     * @param userName 用户名匹配条件参数
     */
    public void setParamByUserName(String userName){
        addParameter(QueryAttr_UserName, userName);
    }

    /**
     * 增加用用户名匹配条件(userName为empty时也会加入此条件)，不空时(target like userName)，key:userName，为空时(target is null or target = '')，key:userName.
     * @param userName 用户名匹配条件参数
     */
    public void setParamByUserNameInEmpty(String userName){
        put(QueryAttr_UserName, userName);
    }

    /**
     * 增加用户名枚举条件(target in (userNames))，key:userName_Enum.
     * @param userNames 用户名数组条件参数
     */
    public void setParamByUserName_Enum(String... userNames){
        addParameterByEnum(QueryAttr_UserName, userNames);
    }

    /**
     * 增加用证件号码匹配条件(target like idCard)，key:idCard.
     * @param idCard 证件号码匹配条件参数
     */
    public void setParamByIdCard(String idCard){
        addParameter(QueryAttr_IdCard, idCard);
    }

    /**
     * 增加用证件号码匹配条件(idCard为empty时也会加入此条件)，不空时(target like idCard)，key:idCard，为空时(target is null or target = '')，key:idCard.
     * @param idCard 证件号码匹配条件参数
     */
    public void setParamByIdCardInEmpty(String idCard){
        put(QueryAttr_IdCard, idCard);
    }

    /**
     * 增加证件号码枚举条件(target in (idCards))，key:idCard_Enum.
     * @param idCards 证件号码数组条件参数
     */
    public void setParamByIdCard_Enum(String... idCards){
        addParameterByEnum(QueryAttr_IdCard, idCards);
    }

    /**
     * 增加用性别匹配条件(sex非0时才会加入此条件)(target = sex)，key:sex.
     * @param sex 性别匹配条件参数
     */
    public void setParamBySex(int sex){
        addParameter(QueryAttr_Sex, sex);
    }

    /**
     * 增加用性别匹配条件(sex为0时也会加入此条件)(target = sex)，key:sex.
     * @param sex 性别匹配条件参数
     */
    public void setParamBySexIncZero(int sex){
        put(QueryAttr_Sex, sex);
    }

    /**
     * 增加性别范围条件（low <= target and target >= high），key:sex_L sex_H.
     * @param low 最小值参数
     * @param high 最大值参数
     */
    public void setParamBySex_Range(int low, int high){
        addParameterByRange(QueryAttr_Sex, low, high);
    }

    /**
     * 增加性别枚举条件(target in (sexs))，key:sex_Enum.
     * @param sexs 性别数组条件参数
     */
    public void setParamBySex_Enum(int... sexs){
        addParameterByEnum(QueryAttr_Sex, sexs);
    }

    /**
     * 增加用电话匹配条件(target like phone)，key:phone.
     * @param phone 电话匹配条件参数
     */
    public void setParamByPhone(String phone){
        addParameter(QueryAttr_Phone, phone);
    }

    /**
     * 增加用电话匹配条件(phone为empty时也会加入此条件)，不空时(target like phone)，key:phone，为空时(target is null or target = '')，key:phone.
     * @param phone 电话匹配条件参数
     */
    public void setParamByPhoneInEmpty(String phone){
        put(QueryAttr_Phone, phone);
    }

    /**
     * 增加电话枚举条件(target in (phones))，key:phone_Enum.
     * @param phones 电话数组条件参数
     */
    public void setParamByPhone_Enum(String... phones){
        addParameterByEnum(QueryAttr_Phone, phones);
    }

}
